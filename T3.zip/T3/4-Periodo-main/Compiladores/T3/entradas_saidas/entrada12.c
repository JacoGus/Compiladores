int func(float b) {
	if(b <= 3 || !1)
		code = l;
	else
		this_thing = for();
    endif
}
