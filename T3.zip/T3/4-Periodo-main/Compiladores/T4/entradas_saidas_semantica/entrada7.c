void main(int argc, char argv) {
    int j=1, i, k[10];
	k[1] = 20;
	k[2] = 4;	
	while(j < k[1]) {
		printf("Agora vai final!");
	}
	imprime();
}
