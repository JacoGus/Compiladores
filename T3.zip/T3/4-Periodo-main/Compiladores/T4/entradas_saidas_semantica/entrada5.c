void main(int argc, char argv) {
    int j=1, i, k[10];
	k[1] = 20.2;
	k[2] = 4;	
	while(j < k[1.3]) {
		printf("Agora vai!");
	}
	imprime();
}
