int soma(int x, int y) {
	int z;
	z = x + y;
}

int sub(int x, int y) {
	int z;
	z = x + y;
}

int main() {
	int a, b;
	b = 10;
	a = 33 - b;
	soma(a,b);
}
