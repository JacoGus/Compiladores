#ifndef ANALEX_H
#define ANALEX_H

int yylex();
int yyerror(char *s);

#endif