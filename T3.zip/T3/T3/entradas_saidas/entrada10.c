int func(float b) {
	if(b <= 3 || !1)
		code = l;
	otherwise{
		this_thing = for();
	}
}
